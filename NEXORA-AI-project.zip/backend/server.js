import express from "express"; import cors from "cors";
const { LLM_BASE_URL, LLM_API_KEY, LLM_MODELS = "", PORT = 8787 } = process.env;
const models = LLM_MODELS.split(",").map(s => s.trim()).filter(Boolean);
const app = express(); app.use(cors()); app.use(express.json({ limit: "15mb" }));
const hits = new Map(); // حد استخدام بسيط: 30 طلب/دقيقة لكل IP
app.use("/api", (req, res, next) => {
  const k = req.ip, now = Date.now(), a = (hits.get(k) || []).filter(t => now - t < 60000);
  if (a.length >= 30) return res.status(429).send("تجاوزت حد الاستخدام / rate limit");
  a.push(now); hits.set(k, a); next();
});
app.get("/api/health", (_, res) => res.json({ ok: true }));
app.get("/api/models", (_, res) => res.json({ models, limit: "30 req/min" }));
app.post("/api/chat", async (req, res) => {
  if (!LLM_API_KEY) return res.status(500).send("الخادم غير مهيأ: LLM_API_KEY مفقود");
  const { messages, model } = req.body || {};
  if (!Array.isArray(messages)) return res.status(400).send("bad request");
  const m = models.includes(model) ? model : models[0];
  const ctl = new AbortController(); res.on("close", () => ctl.abort());
  try {
    const r = await fetch(LLM_BASE_URL + "/chat/completions", {
      method: "POST", signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + LLM_API_KEY },
      body: JSON.stringify({ model: m, messages, stream: true })
    });
    if (!r.ok) return res.status(r.status).send((await r.text()).slice(0, 300));
    res.setHeader("Content-Type", "text/event-stream");
    for await (const c of r.body) res.write(c);
    res.end();
  } catch (e) { if (!res.headersSent) res.status(502).send("upstream error"); else res.end(); }
});
app.listen(PORT, () => console.log("NEXORA backend on :" + PORT));
