# NEXORA AI
## 1) تشغيل الخادم (مجاني)
cd backend && cp .env.example .env && npm i
اضبط المتغيرات ثم: export $(cat .env | xargs) && npm start
استضافة مجانية: Render/Fly.io أو Cloudflare Tunnel من جهازك، أو Ollama محلياً.
## 2) تجربة الواجهة
python -m http.server -d web ثم افتحها وضع رابط الخادم في الإعدادات. يمكن تثبيتها كـ PWA من Chrome على Android.
## 3) بناء APK مجاناً
ارفع المجلد إلى GitHub، عدّل web/config.js برابط خادمك (HTTPS)، ثم Actions → Build APK → نزّل app-debug.apk.
## غير متضمَّن بعد
توليد الصور، البحث على الإنترنت، قراءة PDF/Word، مزامنة سحابية.
