window.NX_SERVER = ""; // ضع رابط خادمك هنا قبل بناء APK، مثال: "https://nexora.example.com"
